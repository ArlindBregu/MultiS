package com.example;


import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MultiServer{

    ArrayList <Server> lista = new ArrayList<>();
    ServerSocket serverSocket = null;

    public void start(){

        try {
            
            serverSocket = new ServerSocket(6789);
            for(;;){

                System.out.println("1 Server in attesa...");
                Socket socket = serverSocket.accept();
                System.out.println("3 Server socket " +socket);
                Server serverT  = new Server(socket, this);  

                serverT.start();

                lista.add(serverT);

               
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante l'istanza del server !");
            System.exit(1);
        }
    }

    public void stop(){

        for(int i=0; i<lista.size(); i++){

            try {
                lista.get(i).close();
            } catch (Exception e) {
               
                e.printStackTrace();
            }
        }

        try {
            serverSocket.close();
        } catch (Exception e) {
           
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
    
        MultiServer tcpServer = new MultiServer();
        tcpServer.start();

    }
}
